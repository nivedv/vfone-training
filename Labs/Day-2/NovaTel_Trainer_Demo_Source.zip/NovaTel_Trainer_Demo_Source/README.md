# NovaTel Portal - Trainer Demo Source (Day 1, Session 2: App Service)

Minimal ASP.NET Core 8 app (no NuGet packages). Same code in both versions - only the version label
and colour differ (v1 = blue, v2 = green).

| File | What it is |
|---|---|
| `portal-v1.zip` | Deployable source for the **production** slot (shows "NovaTel Portal v1") |
| `portal-v2.zip` | Deployable source for the **staging** slot (shows "NovaTel Portal v2") |
| `source-v1/`, `source-v2/` | The same code unzipped, for reading or pushing to Git |
| `load-burn.ps1` | PowerShell 7 load loop against `/burn` for the autoscale demo |

## Endpoints

| Path | Behaviour |
|---|---|
| `/` | Home page: version, slot, instance id, UTC time |
| `/health` | JSON `{status, version, slot, instance}` - use for warm-up path and the swap refresh test |
| `/fail` | Logs an ERROR line and returns HTTP 500 - for Log stream / Diagnose and solve problems |
| `/config` | Shows `PortalEnv` and whether `CosmosConnectionString` resolved from Key Vault (never prints the value) |
| `/burn` | Spins CPU ~300 ms (`/burn?ms=500` to change) - for autoscale |

## Deploy (trainer app: `app-novatel-portal-oc26-trainer`, RG `rg-novatel-oc26-trainer`)

The zips contain **source**, not a published build. App Service builds it on deploy (Oryx), which needs the
app setting `SCM_DO_BUILD_DURING_DEPLOYMENT = true` (the zips also carry a `.deployment` file that sets it).

**Option A - Azure CLI**
```powershell
az webapp config appsettings set -g rg-novatel-oc26-trainer -n app-novatel-portal-oc26-trainer --settings SCM_DO_BUILD_DURING_DEPLOYMENT=true
az webapp deploy -g rg-novatel-oc26-trainer -n app-novatel-portal-oc26-trainer --src-path portal-v1.zip --type zip
# staging slot:
az webapp deploy -g rg-novatel-oc26-trainer -n app-novatel-portal-oc26-trainer --slot staging --src-path portal-v2.zip --type zip
```

**Option B - Portal only (Kudu drag-and-drop)**
1. App -> Environment variables -> add `SCM_DO_BUILD_DURING_DEPLOYMENT` = `true` -> Apply.
2. App -> Development Tools -> Advanced Tools -> Go -> in Kudu: Tools -> Zip Push Deploy.
3. Drag `portal-v1.zip` onto the page. Wait for the build to finish, then browse the app.
4. For the staging slot repeat from the *slot's* own Advanced Tools with `portal-v2.zip`
   (slot app settings are separate - add the setting there too).

**Option C - Git (what participants use)**
```powershell
cd source-v1
git init -b main ; git add . ; git commit -m "NovaTel Portal v1"
git remote add origin <your public repo url> ; git push -u origin main
cd ..\source-v2
git init -b v2 ; git add . ; git commit -m "NovaTel Portal v2"
git remote add origin <your public repo url> ; git push -u origin v2
```
Branch `main` = v1, branch `v2` = v2. Give participants the repo URL as `{labRepoUrl}`.

## Build locally (optional, needs .NET 8 SDK)
```powershell
cd source-v1
dotnet run          # then browse http://localhost:5000 (see console for the port)
```

## Notes
- Runtime stack for the app: **.NET 8 (LTS)** on **Linux**.
- Set the slot's health/warm-up path to `/health` before the swap demo.
- First request after a deploy can take 20-30 s while the app cold-starts; browse it once before class.
- **Not compiled in the authoring sandbox** (no .NET SDK there). Run `dotnet run` or one test deploy before the session.
