# Demo 2 load generator - drives CPU up on the trainer app via /burn (~300 ms of CPU per call).
# Requires PowerShell 7+. Stop with Ctrl+C. Run it in TWO windows if CPU does not climb.
param(
  [string]$Url = "https://app-novatel-portal-oc26-trainer.azurewebsites.net/burn",
  [int]$Requests = 3000,
  [int]$Parallel = 40
)
if ($PSVersionTable.PSVersion.Major -lt 7) { Write-Error "PowerShell 7+ required (winget install Microsoft.PowerShell)"; exit 1 }
Write-Host "Hitting $Url x $Requests with $Parallel parallel calls..."
1..$Requests | ForEach-Object -Parallel {
  try { Invoke-WebRequest -Uri $using:Url -UseBasicParsing -TimeoutSec 60 | Out-Null } catch { }
} -ThrottleLimit $Parallel
Write-Host "Done."
