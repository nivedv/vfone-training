using System.Diagnostics;
using System.Net;

// ---------------------------------------------------------------------------
// NovaTel Portal - sample app for the "Developing Solutions for Microsoft Azure"
// training (Day 1, App Service). Minimal API, .NET 8, no external packages.
//
// The ONLY difference between v1 and v2 is the two values below.
// ---------------------------------------------------------------------------
const string Version = "v1";          // v2 build uses "v2"
const string Accent  = "#0b5ed7";     // v2 build uses "#198754" (green)

var builder = WebApplication.CreateBuilder(args);
var app = builder.Build();

static string Instance()
{
    // Each App Service instance has its own id - handy to show autoscale adding instances.
    var id = Environment.GetEnvironmentVariable("WEBSITE_INSTANCE_ID") ?? Environment.MachineName;
    return id.Length > 8 ? id[..8] : id;
}

static string Slot() => Environment.GetEnvironmentVariable("WEBSITE_SLOT_NAME") ?? "production";

string Page(string title, string body) => $$"""
<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>NovaTel Portal {{Version}}</title>
<style>
  body{font-family:Segoe UI,Arial,sans-serif;margin:0;background:#f4f6f9;color:#1f2937}
  header{background:{{Accent}};color:#fff;padding:28px 40px}
  header h1{margin:0;font-size:40px}
  main{padding:28px 40px;font-size:20px;line-height:1.6}
  code{background:#e5e7eb;padding:2px 6px;border-radius:4px}
  table{border-collapse:collapse;font-size:20px}
  td{padding:6px 18px 6px 0}
  td:first-child{color:#6b7280}
</style></head>
<body>
<header><h1>NovaTel Portal {{Version}}</h1></header>
<main>
<h2>{{title}}</h2>
{{body}}
<p style="margin-top:36px;color:#6b7280;font-size:16px">
Pages: <a href="/">/</a> &middot; <a href="/health">/health</a> &middot; <a href="/config">/config</a> &middot;
<a href="/fail">/fail</a> &middot; <a href="/burn">/burn</a></p>
</main></body></html>
""";

// Home page - what the "customer" sees. Version + accent colour change between v1 and v2.
app.MapGet("/", () => Results.Content(Page("Customer self-service portal",
    $"""
    <table>
      <tr><td>Version</td><td><b>{Version}</b></td></tr>
      <tr><td>Slot</td><td>{Slot()}</td></tr>
      <tr><td>Instance</td><td>{Instance()}</td></tr>
      <tr><td>Server time (UTC)</td><td>{DateTime.UtcNow:HH:mm:ss}</td></tr>
    </table>
    """), "text/html"));

// Health probe - used by slot warm-up / swap and by the "refresh during swap" test.
app.MapGet("/health", () => Results.Json(new
{
    status = "Healthy",
    version = Version,
    slot = Slot(),
    instance = Instance(),
    utc = DateTime.UtcNow
}));

// Always fails with HTTP 500 and writes an error log line -> Log stream / Diagnose and solve problems.
app.MapGet("/fail", (ILogger<Program> log) =>
{
    log.LogError("NovaTel Portal {Version} - intentional failure triggered on /fail at {Utc}", Version, DateTime.UtcNow);
    return Results.Problem(title: "Intentional failure", detail: "This is the /fail demo endpoint.",
                           statusCode: (int)HttpStatusCode.InternalServerError);
});

// Shows the PortalEnv app setting and whether the Key Vault reference resolved.
// The secret value is NEVER printed.
app.MapGet("/config", (IConfiguration cfg) =>
{
    var env    = cfg["PortalEnv"] ?? "(not set)";
    var secret = cfg["CosmosConnectionString"];

    string state;
    if (string.IsNullOrEmpty(secret))
        state = "NOT SET - add the app setting CosmosConnectionString";
    else if (secret.StartsWith("@Microsoft.KeyVault", StringComparison.OrdinalIgnoreCase))
        state = "NOT RESOLVED - still the raw reference (check identity + Key Vault access policy)";
    else
        state = $"RESOLVED from Key Vault ({secret.Length} characters, value hidden)";

    return Results.Content(Page("Configuration",
        $"""
        <table>
          <tr><td>PortalEnv</td><td><b>{WebUtility.HtmlEncode(env)}</b></td></tr>
          <tr><td>CosmosConnectionString</td><td><b>{WebUtility.HtmlEncode(state)}</b></td></tr>
          <tr><td>Slot</td><td>{Slot()}</td></tr>
          <tr><td>Version</td><td>{Version}</td></tr>
        </table>
        """), "text/html");
});

// CPU burner for the autoscale demo: spins ~300 ms of CPU per call.
app.MapGet("/burn", (int? ms) =>
{
    var budget = TimeSpan.FromMilliseconds(Math.Clamp(ms ?? 300, 10, 5000));
    var sw = Stopwatch.StartNew();
    double x = 0;
    while (sw.Elapsed < budget)
        x += Math.Sqrt(Random.Shared.NextDouble() * 1000);
    return Results.Json(new { burnedMs = (int)sw.ElapsedMilliseconds, instance = Instance(), checksum = Math.Round(x) });
});

app.Run();
