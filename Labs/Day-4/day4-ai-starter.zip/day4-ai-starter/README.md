# Day 4 Application Insights starter (baseline for Labs 1 and 2)

Contents
- portal/    NovaTel.Portal  - ASP.NET Core 8 minimal app: /, /health (anonymous), /invoice/{id}. No Application Insights packages.
- function/  NovaTel.Billing - .NET 8 isolated Function: GenerateInvoice writes invoice JSON to Blob Storage.
              Worker Application Insights wiring is present but inert until APPLICATIONINSIGHTS_CONNECTION_STRING is set.
              Setting BILLING_FAULT_MODE=storage-latency adds 3-8 s delay and 30% timeouts inside the Blob call (Lab 2).
- scripts/publish-packages.ps1  builds func.zip and web.zip and prints read-only links for the portal-only lab (Part A).
- scripts/deploy-day4-ai.ps1  fallback: provisions one participant group end to end. scripts/set-fault.ps1 toggles the fault for rehearsal.

Prerequisites (trainer machine): Azure CLI signed in, .NET 8 SDK, PowerShell. Needs outbound NuGet access.

STATUS: written without a .NET SDK or NuGet access, so nothing is compiled or deployed. Before class:
1. dotnet build both projects; fix any package version that no longer exists.
2. Run deploy-day4-ai.ps1 -Id test01 and check /health and /invoice/INV-1001 return 200.
3. Run set-fault.ps1 -Id test01 -On, call the invoice page ~20 times, then confirm after Lab 1 wiring that the KQL pack shows the storage dependency slow.
4. Confirm the portal Application Insights toggle works for this Linux B1 app (no App Insights packages are referenced).
Cleanup: delete the group (nightly script) - everything here lives in rg-nvtl-oct26-<id>.
