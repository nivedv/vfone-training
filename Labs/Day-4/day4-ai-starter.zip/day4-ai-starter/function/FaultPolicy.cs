using Azure.Core;
using Azure.Core.Pipeline;

namespace NovaTel.Billing;

// Lab 2 seeded issue. Only added to the Blob client when BILLING_FAULT_MODE=storage-latency.
// Sits inside the Azure SDK call, so the storage dependency shows a high p95 and intermittent timeout failures.
public sealed class FaultPolicy : HttpPipelinePolicy
{
    private static void Fail()
    {
        if (Random.Shared.Next(100) < 30)
            throw new TimeoutException("Simulated Blob Storage write timeout (BILLING_FAULT_MODE)");
    }

    public override void Process(HttpMessage message, ReadOnlyMemory<HttpPipelinePolicy> pipeline)
    {
        Thread.Sleep(Random.Shared.Next(3000, 8000));
        Fail();
        ProcessNext(message, pipeline);
    }

    public override async ValueTask ProcessAsync(HttpMessage message, ReadOnlyMemory<HttpPipelinePolicy> pipeline)
    {
        await Task.Delay(Random.Shared.Next(3000, 8000));
        Fail();
        await ProcessNextAsync(message, pipeline);
    }
}
