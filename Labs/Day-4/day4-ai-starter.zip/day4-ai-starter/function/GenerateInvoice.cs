using System.Net;
using Azure.Core;
using Azure.Storage.Blobs;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.Logging;

namespace NovaTel.Billing;

public class GenerateInvoice
{
    private readonly ILogger<GenerateInvoice> _log;
    public GenerateInvoice(ILogger<GenerateInvoice> log) => _log = log;

    // GET /api/GenerateInvoice?invoiceId=INV-1001   (synthetic data only)
    [Function("GenerateInvoice")]
    public async Task<HttpResponseData> Run(
        [HttpTrigger(AuthorizationLevel.Function, "get", "post")] HttpRequestData req)
    {
        var query = System.Web.HttpUtility.ParseQueryString(req.Url.Query);
        var invoiceId = query["invoiceId"] ?? $"INV-{Random.Shared.Next(1000, 9999)}";

        var invoice = new
        {
            invoiceId,
            customerId = "C-2001",
            amount = Math.Round(500 + Random.Shared.NextDouble() * 1500, 2),
            currency = "INR",
            status = "Issued",
            generatedUtc = DateTime.UtcNow
        };

        var options = new BlobClientOptions();
        var fault = Environment.GetEnvironmentVariable("BILLING_FAULT_MODE") == "storage-latency";
        if (fault) options.AddPolicy(new FaultPolicy(), HttpPipelinePosition.PerCall);

        var service = new BlobServiceClient(Environment.GetEnvironmentVariable("INVOICE_STORAGE"), options);
        var blob = service.GetBlobContainerClient("invoices").GetBlobClient($"{invoiceId}.json");

        try
        {
            await blob.UploadAsync(BinaryData.FromObjectAsJson(invoice), overwrite: true);
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "Writing invoice {InvoiceId} to Blob Storage failed", invoiceId);
            var failed = req.CreateResponse(HttpStatusCode.GatewayTimeout);
            await failed.WriteStringAsync("Invoice storage timed out");
            return failed;
        }

        _log.LogInformation("Generated invoice {InvoiceId}", invoiceId);
        var ok = req.CreateResponse(HttpStatusCode.OK);
        await ok.WriteAsJsonAsync(invoice);
        return ok;
    }
}
