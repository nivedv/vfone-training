Put func.zip and web.zip here (built by scripts/build-packages.ps1). Participants download both and upload them in Part A.
