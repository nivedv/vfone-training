// NovaTel self-care portal (Day 4 starter). Deliberately has NO Application Insights packages:
// participants switch monitoring on from the App Service blade in Lab 1.
var builder = WebApplication.CreateBuilder(args);
builder.Services.AddHttpClient("billing", c => c.Timeout = TimeSpan.FromSeconds(20));
var app = builder.Build();

app.MapGet("/", () => Results.Content(
    "<h1>NovaTel self-care portal</h1><p><a href='/invoice/INV-1001'>View invoice INV-1001</a></p>" +
    "<p><a href='/invoice/INV-1002'>View invoice INV-1002</a></p><p><a href='/health'>Health</a></p>",
    "text/html"));

// Anonymous on purpose: availability tests probe this path (exclude it if you later add Entra sign-in).
app.MapGet("/health", () => Results.Text("ok"));

app.MapGet("/invoice/{id}", async (string id, IHttpClientFactory factory, IConfiguration cfg) =>
{
    var baseUrl = cfg["BILLING_FUNCTION_URL"];
    var key = cfg["BILLING_FUNCTION_KEY"];
    if (string.IsNullOrEmpty(baseUrl)) return Results.Problem("BILLING_FUNCTION_URL is not set", statusCode: 500);

    var url = $"{baseUrl.TrimEnd('/')}/api/GenerateInvoice?invoiceId={Uri.EscapeDataString(id)}&code={key}";
    try
    {
        var resp = await factory.CreateClient("billing").GetAsync(url);
        var body = await resp.Content.ReadAsStringAsync();
        return Results.Content(body, resp.IsSuccessStatusCode ? "application/json" : "text/plain", null, (int)resp.StatusCode);
    }
    catch (Exception ex) when (ex is HttpRequestException or TaskCanceledException)
    {
        return Results.Problem("Billing service did not respond in time", statusCode: 504);
    }
});

app.Run();
