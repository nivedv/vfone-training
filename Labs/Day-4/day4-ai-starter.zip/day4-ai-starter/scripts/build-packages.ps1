<#
 Builds packages\func.zip and packages\web.zip for the participant guide (Part A, step 7 and 12).
 Commit the two zips to the repo's packages\ folder. Needs: .NET 8 SDK, Windows 10+ (tar.exe), PowerShell. UNTESTED.
#>
$ErrorActionPreference = 'Stop'
$root = Split-Path $PSScriptRoot -Parent
$out  = Join-Path $root 'packages'
$work = Join-Path ([IO.Path]::GetTempPath()) 'nvtl-day4-build'
if (Test-Path $work) { Remove-Item $work -Recurse -Force }
New-Item -ItemType Directory $work, $out -Force | Out-Null

foreach ($p in @(@{src='function'; zip='func.zip'}, @{src='portal'; zip='web.zip'})) {
  $pub = Join-Path $work $p.src
  dotnet publish (Join-Path $root $p.src) -c Release -o $pub
  if ($LASTEXITCODE) { throw "dotnet publish $($p.src) failed" }
  $zip = Join-Path $out $p.zip
  if (Test-Path $zip) { Remove-Item $zip }
  # tar writes forward-slash entry names; Compress-Archive in Windows PowerShell 5.1 does not (breaks Linux deploys)
  tar -a -c -f $zip -C $pub .
  if ($LASTEXITCODE) { throw "tar failed for $($p.zip)" }
  Write-Host "Built $zip"
}
