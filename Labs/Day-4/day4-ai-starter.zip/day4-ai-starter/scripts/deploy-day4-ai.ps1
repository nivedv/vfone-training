<#
 Provisions the Day 4 Application Insights lab baseline into ONE participant group:
   storage account + 'invoices' container, billing Function app, portal App Service.
 Run before class, from a machine with: Azure CLI (signed in), .NET 8 SDK, PowerShell 5.1+.
 Usage:  .\deploy-day4-ai.ps1 -Id p01
 UNTESTED against a live subscription - dry-run once first.
#>
param(
  [Parameter(Mandatory)][ValidatePattern('^[a-z0-9]{2,8}$')][string]$Id,
  [string]$Location = 'centralindia'
)
$ErrorActionPreference = 'Stop'
function Invoke-Az { $out = & az @args; if ($LASTEXITCODE -ne 0) { throw "az $($args -join ' ') failed (exit $LASTEXITCODE)" }; return $out }

$root    = Split-Path $PSScriptRoot -Parent
$rg      = "rg-nvtl-oct26-$Id"
$storage = "stnvtl$Id"
$func    = "func-nvtl-billing-$Id"
$plan    = "asp-nvtl-$Id"
$web     = "app-nvtl-portal-$Id"
$tags    = @('course=azure-dev', 'day=4', "owner=$Id", 'CostCenter=BFL-Training')

Write-Host "Resource group $rg"
Invoke-Az group create -n $rg -l $Location --tags @tags | Out-Null

Write-Host "Storage account $storage"
Invoke-Az storage account create -n $storage -g $rg -l $Location --sku Standard_LRS --kind StorageV2 --allow-blob-public-access false --tags @tags | Out-Null
$conn = Invoke-Az storage account show-connection-string -n $storage -g $rg --query connectionString -o tsv
Invoke-Az storage container create -n invoices --connection-string $conn | Out-Null

Write-Host "Function app $func"
Invoke-Az functionapp create -n $func -g $rg --storage-account $storage --consumption-plan-location $Location `
  --runtime dotnet-isolated --runtime-version 8 --functions-version 4 --os-type Windows --tags @tags | Out-Null
Invoke-Az functionapp config appsettings set -n $func -g $rg --settings "INVOICE_STORAGE=$conn" | Out-Null

Write-Host "Portal App Service $web"
Invoke-Az appservice plan create -n $plan -g $rg -l $Location --is-linux --sku B1 --tags @tags | Out-Null
Invoke-Az webapp create -n $web -g $rg -p $plan --runtime 'DOTNETCORE:8.0' --tags @tags | Out-Null

$work = Join-Path ([IO.Path]::GetTempPath()) "nvtl-day4-$Id"
if (Test-Path $work) { Remove-Item $work -Recurse -Force }
New-Item -ItemType Directory $work | Out-Null

Write-Host 'Publishing Function'
dotnet publish (Join-Path $root 'function') -c Release -o (Join-Path $work 'func-out'); if ($LASTEXITCODE) { throw 'dotnet publish (function) failed' }
tar -a -c -f (Join-Path $work 'func.zip') -C (Join-Path $work 'func-out') .
Invoke-Az functionapp deployment source config-zip -n $func -g $rg --src (Join-Path $work 'func.zip') | Out-Null

Write-Host 'Reading function key (waits for the host to start)'
$key = $null
foreach ($i in 1..12) {
  $key = (& az functionapp keys list -n $func -g $rg --query 'functionKeys.default' -o tsv 2>$null)
  if ($key) { break }
  Start-Sleep -Seconds 15
}
if (-not $key) { throw 'Function key not available yet. Re-run the "Connect portal" part manually.' }
$funcUrl = "https://$(Invoke-Az functionapp show -n $func -g $rg --query defaultHostName -o tsv)"

Write-Host 'Publishing Portal'
dotnet publish (Join-Path $root 'portal') -c Release -o (Join-Path $work 'web-out'); if ($LASTEXITCODE) { throw 'dotnet publish (portal) failed' }
tar -a -c -f (Join-Path $work 'web.zip') -C (Join-Path $work 'web-out') .
Invoke-Az webapp config appsettings set -n $web -g $rg --settings "BILLING_FUNCTION_URL=$funcUrl" "BILLING_FUNCTION_KEY=$key" | Out-Null
Invoke-Az webapp deploy -n $web -g $rg --src-path (Join-Path $work 'web.zip') --type zip | Out-Null

$portalUrl = "https://$(Invoke-Az webapp show -n $web -g $rg --query defaultHostName -o tsv)"
Write-Host "Smoke test..."
Start-Sleep -Seconds 20
foreach ($p in '/health', '/invoice/INV-1001') {
  try { $r = Invoke-WebRequest "$portalUrl$p" -UseBasicParsing; Write-Host "$p -> $($r.StatusCode)" }
  catch { Write-Warning "$p failed: $($_.Exception.Message)" }
}
Write-Host "`nPortal : $portalUrl`nFunction: $funcUrl`nGroup  : $rg"
