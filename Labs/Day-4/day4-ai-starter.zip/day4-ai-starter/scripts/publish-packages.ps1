<#
 Builds the portal and Function zips and publishes them as read-only links for the portal-only lab (Part A).
 Run once, the evening before. Needs: Azure CLI signed in, .NET 8 SDK, PowerShell.
 Usage: .\publish-packages.ps1 -StorageAccount stnvtlplatform01 -Days 2
 The storage account lives in rg-nvtl-platform (NOT a daily participant group). UNTESTED - dry-run first.
#>
param(
  [Parameter(Mandatory)][ValidatePattern('^[a-z0-9]{3,24}$')][string]$StorageAccount,
  [string]$ResourceGroup = 'rg-nvtl-platform',
  [string]$Location = 'centralindia',
  [int]$Days = 2
)
$ErrorActionPreference = 'Stop'
function Invoke-Az { $out = & az @args; if ($LASTEXITCODE -ne 0) { throw "az $($args -join ' ') failed (exit $LASTEXITCODE)" }; return $out }

$root = Split-Path $PSScriptRoot -Parent
$work = Join-Path ([IO.Path]::GetTempPath()) 'nvtl-day4-packages'
if (Test-Path $work) { Remove-Item $work -Recurse -Force }
New-Item -ItemType Directory $work | Out-Null

dotnet publish (Join-Path $root 'function') -c Release -o (Join-Path $work 'func-out'); if ($LASTEXITCODE) { throw 'publish function failed' }
dotnet publish (Join-Path $root 'portal')   -c Release -o (Join-Path $work 'web-out');  if ($LASTEXITCODE) { throw 'publish portal failed' }
Compress-Archive -Path (Join-Path $work 'func-out\*') -DestinationPath (Join-Path $work 'func.zip') -Force
Compress-Archive -Path (Join-Path $work 'web-out\*')  -DestinationPath (Join-Path $work 'web.zip')  -Force

Invoke-Az group create -n $ResourceGroup -l $Location --tags CostCenter=BFL-Training | Out-Null
Invoke-Az storage account create -n $StorageAccount -g $ResourceGroup -l $Location --sku Standard_LRS --allow-blob-public-access false --tags CostCenter=BFL-Training | Out-Null
$key = Invoke-Az storage account keys list -n $StorageAccount -g $ResourceGroup --query '[0].value' -o tsv
Invoke-Az storage container create -n packages --account-name $StorageAccount --account-key $key | Out-Null
foreach ($f in 'func.zip', 'web.zip') {
  Invoke-Az storage blob upload --account-name $StorageAccount --account-key $key -c packages -n $f -f (Join-Path $work $f) --overwrite | Out-Null
}
$expiry = (Get-Date).ToUniversalTime().AddDays($Days).ToString('yyyy-MM-ddTHH:mmZ')
$sasFunc = Invoke-Az storage blob generate-sas --account-name $StorageAccount --account-key $key -c packages -n func.zip --permissions r --expiry $expiry --https-only -o tsv
$sasWeb  = Invoke-Az storage blob generate-sas --account-name $StorageAccount --account-key $key -c packages -n web.zip  --permissions r --expiry $expiry --https-only -o tsv
Write-Host "`n<FUNCTION_PACKAGE_URL> = https://$StorageAccount.blob.core.windows.net/packages/func.zip?$sasFunc"
Write-Host "`n<PORTAL_PACKAGE_URL>   = https://$StorageAccount.blob.core.windows.net/packages/web.zip?$sasWeb"
Write-Host "`nLinks expire $expiry UTC. Treat them as secrets until class."
