# Trainer rehearsal helper: switch the Lab 2 seeded issue on or off for one participant.
# Usage: .\set-fault.ps1 -Id p01 -On   |   .\set-fault.ps1 -Id p01
param([Parameter(Mandatory)][string]$Id, [switch]$On)
$rg = "rg-nvtl-oct26-$Id"; $func = "func-nvtl-billing-$Id"
if ($On) { az functionapp config appsettings set -n $func -g $rg --settings BILLING_FAULT_MODE=storage-latency | Out-Null; 'Fault ON' }
else     { az functionapp config appsettings delete -n $func -g $rg --setting-names BILLING_FAULT_MODE | Out-Null; 'Fault OFF' }
