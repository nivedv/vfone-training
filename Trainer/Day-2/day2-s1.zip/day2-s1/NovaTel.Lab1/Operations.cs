using System.Diagnostics;
using Microsoft.Azure.Cosmos;

namespace NovaTel.Lab1;

/// <summary>
/// Complete every method marked TODO. Each method must print the RU charge and the elapsed
/// milliseconds so you can fill in the lab table. Hints are in the comments.
/// </summary>
public class Operations
{
    private readonly Container _customers;
    public Operations(Container customers) => _customers = customers;

    // A2. Insert a new profile. Partition key value must equal the item's customerId.
    // Hint: _customers.CreateItemAsync(item, new PartitionKey(item.CustomerId))
    public async Task CreateAsync(string id)
    {
        var sw = Stopwatch.StartNew();
        // TODO: build a CustomerProfile (country "IN", plan "Postpaid-Standard", fee 49) and create it.
        await Task.CompletedTask;
        Console.WriteLine($"TODO Create: print RU and {sw.ElapsedMilliseconds} ms");
    }

    // A3. Point read = id + partition key. Cheapest and fastest operation in Cosmos DB.
    // Hint: ReadItemAsync<CustomerProfile>(id, new PartitionKey(id)); response.RequestCharge
    public async Task ReadAsync(string id)
    {
        var sw = Stopwatch.StartNew();
        // TODO
        await Task.CompletedTask;
        Console.WriteLine($"TODO Read: print RU and {sw.ElapsedMilliseconds} ms");
    }

    // A4. Parameterised cross-partition query. Sum RequestCharge across ALL pages.
    // Hint: QueryDefinition("SELECT * FROM c WHERE c.plan = @plan AND c.country = @country")
    //       .WithParameter("@plan", plan) ... GetItemQueryIterator<CustomerProfile>(q)
    public async Task QueryAsync(string plan, string country)
    {
        var sw = Stopwatch.StartNew();
        // TODO
        await Task.CompletedTask;
        Console.WriteLine($"TODO Query: print matches, total RU and {sw.ElapsedMilliseconds} ms");
    }

    // A5. Upgrade the plan with optimistic concurrency.
    // Hint: read first, keep response.ETag, then ReplaceItemAsync(updated, id, pk,
    //       new ItemRequestOptions { IfMatchEtag = etag })
    public async Task ReplaceAsync(string id)
    {
        var sw = Stopwatch.StartNew();
        // TODO: upgrade to "Postpaid-Premium" fee 79.
        await Task.CompletedTask;
        Console.WriteLine($"TODO Replace: print RU and {sw.ElapsedMilliseconds} ms");
    }

    // A5 (second half). Replace again using the OLD ETag. Expect HTTP 412 PreconditionFailed.
    // The Step() wrapper in Program.cs prints the CosmosException for you.
    public async Task StaleEtagAsync(string id)
    {
        // TODO: capture an ETag, change the item once, then try to replace with the captured (now stale) ETag.
        await Task.CompletedTask;
        Console.WriteLine("TODO StaleEtag: you should see a 412 in the output above this line.");
    }

    // A6. Delete your test profile.
    public async Task DeleteAsync(string id)
    {
        var sw = Stopwatch.StartNew();
        // TODO: DeleteItemAsync<CustomerProfile>(id, new PartitionKey(id))
        await Task.CompletedTask;
        Console.WriteLine($"TODO Delete: print RU and {sw.ElapsedMilliseconds} ms");
    }

    // B. Print the account's default consistency level.
    // Hint: AccountProperties props = await client.ReadAccountAsync(); props.Consistency.DefaultConsistencyLevel
    public async Task PrintAccountConsistencyAsync(CosmosClient client)
    {
        // TODO
        await Task.CompletedTask;
        Console.WriteLine("TODO: print default consistency level");
    }

    // B. A client may RELAX consistency per request, never strengthen it beyond the account default.
    // Hint: new ItemRequestOptions { ConsistencyLevel = level }
    // Stretch: try ConsistencyLevel.Strong on a Session account and observe the exception.
    public async Task ReadWithConsistencyAsync(string id, ConsistencyLevel level)
    {
        var sw = Stopwatch.StartNew();
        // TODO
        await Task.CompletedTask;
        Console.WriteLine($"TODO ReadWithConsistency({level}): print RU and {sw.ElapsedMilliseconds} ms");
    }
}
