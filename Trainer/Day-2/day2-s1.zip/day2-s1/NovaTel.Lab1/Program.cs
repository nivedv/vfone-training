// NovaTel Day 2 - Lab 1: customer profile CRUD and consistency choice.
// Work through the TODOs in Operations.cs, then run:  dotnet run --project NovaTel.Lab1
using Microsoft.Azure.Cosmos;
using NovaTel.Lab1;

var endpoint = Config.Get("COSMOS_ENDPOINT");
var key      = Config.Get("COSMOS_KEY");
var me       = Config.Get("PARTICIPANT_ID");

// Part A, step 1: ONE client for the whole app (it is thread-safe and expensive to create).
using var client = new CosmosClient(endpoint, key, new CosmosClientOptions
{
    ApplicationName = "NovaTel-Lab1",
    SerializerOptions = new CosmosSerializationOptions { PropertyNamingPolicy = CosmosPropertyNamingPolicy.CamelCase }
});

Container customers = client.GetContainer("novatel", "customers");
var ops = new Operations(customers);
var profileId = $"c-{me}-01";

async Task Step(string name, Func<Task> action)
{
    Console.WriteLine($"\n=== {name} ===");
    try { await action(); }
    catch (CosmosException ex) { Console.WriteLine($"CosmosException {(int)ex.StatusCode} {ex.StatusCode}: {ex.SubStatusCode} RU={ex.RequestCharge}"); }
}

await Step("Part A2: Create",             () => ops.CreateAsync(profileId));
await Step("Part A3: Point read",         () => ops.ReadAsync(profileId));
await Step("Part A4: Query",              () => ops.QueryAsync("Postpaid-Standard", "IN"));
await Step("Part A5: Replace (ETag)",     () => ops.ReplaceAsync(profileId));
await Step("Part A5: Stale ETag (412)",   () => ops.StaleEtagAsync(profileId));
await Step("Part A6: Delete",             () => ops.DeleteAsync(profileId));
await Step("Part B: Account default",     () => ops.PrintAccountConsistencyAsync(client));
await Step("Part B: Per-request Eventual", () => ops.ReadWithConsistencyAsync("c-1001", ConsistencyLevel.Eventual));

Console.WriteLine("\nDone. Fill in the RU / latency table in your lab notes.");
