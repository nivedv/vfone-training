namespace BillingWorker;

public record PlanChange(string Id, string CustomerId, string Plan, decimal MonthlyFee);

public record BillingNotification(string Id, string CustomerId, string Message, DateTime CreatedUtc);

public static class Config
{
    public static string Get(string name) =>
        Environment.GetEnvironmentVariable(name)
        ?? throw new InvalidOperationException($"Environment variable {name} is not set. Run: . .\\scripts\\load-env.ps1 -Id <yourId>");
}
