// NovaTel Day 2 - Lab 2 Part A: change feed -> billing notification.
// The processor is already wired. Complete HandleChangesAsync (TODO), then:
//   terminal 1:  dotnet run --project NovaTel.Lab2/BillingWorker
//   terminal 2:  dotnet run --project NovaTel.Lab2/PlanSimulator -- upgrade c-3001 Postpaid-Premium 79
using Microsoft.Azure.Cosmos;
using BillingWorker;

using var client = new CosmosClient(Config.Get("COSMOS_ENDPOINT"), Config.Get("COSMOS_KEY"), new CosmosClientOptions
{
    ApplicationName = "NovaTel-BillingWorker",
    SerializerOptions = new CosmosSerializationOptions { PropertyNamingPolicy = CosmosPropertyNamingPolicy.CamelCase }
});

Container plans  = client.GetContainer("novatel", "plans");                  // monitored container
Container leases = client.GetContainer("novatel", "leases");                 // progress + work sharing
Container notify = client.GetContainer("novatel", "billing-notifications");  // output

ChangeFeedProcessor processor = plans
    .GetChangeFeedProcessorBuilder<PlanChange>("billingProcessor", HandleChangesAsync)
    .WithInstanceName(Environment.MachineName)
    .WithLeaseContainer(leases)
    .WithStartTime(DateTime.UtcNow)   // only applies the FIRST time leases are created; restarts resume from the lease
    .Build();

await processor.StartAsync();
Console.WriteLine("Billing processor running. Press Enter to stop.");
Console.ReadLine();
await processor.StopAsync();

async Task HandleChangesAsync(
    ChangeFeedProcessorContext context,
    IReadOnlyCollection<PlanChange> changes,
    CancellationToken cancellationToken)
{
    foreach (var change in changes)
    {
        Console.WriteLine($"[lease {context.LeaseToken}] {change.CustomerId} -> {change.Plan} @ {change.MonthlyFee}");

        // TODO 1: create a BillingNotification with message
        //         $"Plan changed to {change.Plan}; prorate from {DateTime.UtcNow:yyyy-MM-dd}".
        // TODO 2: make it IDEMPOTENT. The change feed is at-least-once, so a replayed batch must not
        //         create duplicates: use Id = $"{change.CustomerId}-{change.Plan}-{change.MonthlyFee}"
        //         and UpsertItemAsync (not CreateItemAsync).
        // TODO 3: write it to 'notify' with new PartitionKey(notification.CustomerId).
        await Task.CompletedTask;
    }
}
