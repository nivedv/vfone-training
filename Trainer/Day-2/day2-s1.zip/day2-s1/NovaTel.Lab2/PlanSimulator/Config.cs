namespace PlanSimulator;

public static class Config
{
    public static string Get(string name) =>
        Environment.GetEnvironmentVariable(name)
        ?? throw new InvalidOperationException($"Environment variable {name} is not set. Run: . .\\scripts\\load-env.ps1 -Id <yourId>");
}
