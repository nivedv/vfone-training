// Simulates the Self-Care portal upgrading a customer's plan (writes to the 'plans' container).
// Usage: dotnet run --project NovaTel.Lab2/PlanSimulator -- upgrade <customerId> <plan> <monthlyFee>
using Microsoft.Azure.Cosmos;
using PlanSimulator;

if (args.Length != 4 || args[0] != "upgrade")
{
    Console.WriteLine("Usage: upgrade <customerId> <plan> <monthlyFee>   e.g. upgrade c-3001 Postpaid-Premium 79");
    return;
}

var customerId = args[1];
var plan = args[2];
var fee = decimal.Parse(args[3], System.Globalization.CultureInfo.InvariantCulture);

using var client = new CosmosClient(Config.Get("COSMOS_ENDPOINT"), Config.Get("COSMOS_KEY"), new CosmosClientOptions
{
    ApplicationName = "NovaTel-PlanSimulator",
    SerializerOptions = new CosmosSerializationOptions { PropertyNamingPolicy = CosmosPropertyNamingPolicy.CamelCase }
});
var plans = client.GetContainer("novatel", "plans");

// One document per customer: each upsert is an update the change feed will deliver.
var change = new PlanChange(customerId, customerId, plan, fee);
var r = await plans.UpsertItemAsync(change, new PartitionKey(customerId));
Console.WriteLine($"Upserted {customerId} -> {plan} @ {fee} (RU {r.RequestCharge})");

public record PlanChange(string Id, string CustomerId, string Plan, decimal MonthlyFee);
