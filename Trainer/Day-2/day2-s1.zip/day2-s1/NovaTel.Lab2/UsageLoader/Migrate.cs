using Microsoft.Azure.Cosmos;

namespace UsageLoader;

public static class Migrate
{
    /// <summary>
    /// Copy every item from <paramref name="source"/> into <paramref name="target"/>.
    /// The target container is partitioned on /customerId, so each write needs
    /// new PartitionKey(item.CustomerId).
    /// </summary>
    public static async Task RunAsync(string endpoint, string key, string source, string target)
    {
        // TODO 1: create a CosmosClient with AllowBulkExecution = true (bulk mode batches many small writes
        //         into few requests: compare elapsed time with and without it if you have spare minutes).
        // TODO 2: get Container objects for 'source' and 'target' in database "novatel".
        // TODO 3: page through the source:  GetItemQueryIterator<UsageEvent>("SELECT * FROM c")
        // TODO 4: for each page, start one UpsertItemAsync per item (do not await inside the loop),
        //         then await Task.WhenAll(...). Sum RequestCharge and count items.
        // TODO 5: print count, total RU and elapsed time.
        await Task.CompletedTask;
        Console.WriteLine("TODO: implement Migrate.RunAsync");
    }
}
