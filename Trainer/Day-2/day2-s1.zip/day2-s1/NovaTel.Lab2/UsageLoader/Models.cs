namespace UsageLoader;

public record UsageEvent(string Id, string CustomerId, string Country, string Month, int MegaBytes, DateTime TimestampUtc);

public record KeyCount(string Grp, long Events);

public static class Config
{
    public static string Get(string name) =>
        Environment.GetEnvironmentVariable(name)
        ?? throw new InvalidOperationException($"Environment variable {name} is not set. Run: . .\\scripts\\load-env.ps1 -Id <yourId>");
}
