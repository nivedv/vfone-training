// NovaTel Day 2 - Lab 2 Part B helper: measure skew, compare query cost, migrate to a better key.
//   dotnet run --project NovaTel.Lab2/UsageLoader -- skew usage-events
//   dotnet run --project NovaTel.Lab2/UsageLoader -- customer-usage usage-events c-1001
//   dotnet run --project NovaTel.Lab2/UsageLoader -- migrate usage-events usage-events-v2     (you complete Migrate.cs)
//   dotnet run --project NovaTel.Lab2/UsageLoader -- skew usage-events-v2
//   dotnet run --project NovaTel.Lab2/UsageLoader -- customer-usage usage-events-v2 c-1001
using Microsoft.Azure.Cosmos;
using UsageLoader;

if (args.Length < 2)
{
    Console.WriteLine("Commands: skew <container> | customer-usage <container> <customerId> | migrate <source> <target>");
    return;
}

var endpoint = Config.Get("COSMOS_ENDPOINT");
var key = Config.Get("COSMOS_KEY");
var options = new CosmosClientOptions
{
    ApplicationName = "NovaTel-UsageLoader",
    SerializerOptions = new CosmosSerializationOptions { PropertyNamingPolicy = CosmosPropertyNamingPolicy.CamelCase }
};

if (args[0] == "migrate")
{
    if (args.Length != 3) { Console.WriteLine("migrate <source> <target>"); return; }
    await Migrate.RunAsync(endpoint, key, args[1], args[2]);
    return;
}

using var client = new CosmosClient(endpoint, key, options);
var container = client.GetContainer("novatel", args[1]);
var props = (await container.ReadContainerAsync()).Resource;
string pkPath;
try { pkPath = props.PartitionKeyPath; }                       // e.g. "/country"
catch (NotImplementedException) { pkPath = props.PartitionKeyPaths[0]; }   // hierarchical keys (stretch task): first level
Console.WriteLine($"Container {args[1]} partition key: {pkPath}");

switch (args[0])
{
    case "skew":
    {
        // Group by whatever the container is partitioned on: this shows how evenly data spreads.
        var field = pkPath.TrimStart('/');
        var q = new QueryDefinition($"SELECT c.{field} AS grp, COUNT(1) AS events FROM c GROUP BY c.{field}");
        var rows = new List<KeyCount>();
        double ru = 0;
        using var it = container.GetItemQueryIterator<KeyCount>(q);
        while (it.HasMoreResults) { var page = await it.ReadNextAsync(); ru += page.RequestCharge; rows.AddRange(page); }
        var total = rows.Sum(r => r.Events);
        Console.WriteLine($"{rows.Count} distinct key values, {total} events, {ru:F1} RU");
        foreach (var r in rows.OrderByDescending(r => r.Events).Take(5))
            Console.WriteLine($"  {r.Grp,-12} {r.Events,6}  {100.0 * r.Events / total,5:F1}%");
        break;
    }
    case "customer-usage":
    {
        // "Usage for one customer in a billing month" - the dominant NovaTel query.
        var customerId = args[2];
        var q = new QueryDefinition("SELECT VALUE COUNT(1) FROM c WHERE c.customerId = @id AND c.month = @m")
            .WithParameter("@id", customerId).WithParameter("@m", "2026-10");
        // If the container is partitioned on /customerId the query can be scoped to ONE logical partition.
        var qo = pkPath == "/customerId" ? new QueryRequestOptions { PartitionKey = new PartitionKey(customerId) } : null;
        double ru = 0; long count = 0;
        using var it = container.GetItemQueryIterator<long>(q, requestOptions: qo);
        while (it.HasMoreResults) { var page = await it.ReadNextAsync(); ru += page.RequestCharge; count += page.Sum(); }
        Console.WriteLine($"{customerId}: {count} events this month, {ru:F2} RU ({(qo is null ? "cross-partition" : "single partition")})");
        break;
    }
    default:
        Console.WriteLine("Unknown command.");
        break;
}
