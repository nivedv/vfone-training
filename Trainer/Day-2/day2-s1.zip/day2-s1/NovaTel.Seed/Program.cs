// Seeds 200 customer profiles and 5,000 usage events (90% country = "IN") for Day 2 Session 1.
// Idempotent: uses upserts, safe to run twice.
using Microsoft.Azure.Cosmos;
using NovaTel.Seed;

var endpoint = Config.Get("COSMOS_ENDPOINT");
var key      = Config.Get("COSMOS_KEY");

using var client = new CosmosClient(endpoint, key, new CosmosClientOptions
{
    ApplicationName = "NovaTel-Seed",
    AllowBulkExecution = true,
    MaxRetryAttemptsOnRateLimitedRequests = 20,                       // serverless can burst-throttle during seeding
    MaxRetryWaitTimeOnRateLimitedRequests = TimeSpan.FromSeconds(120),
    SerializerOptions = new CosmosSerializationOptions { PropertyNamingPolicy = CosmosPropertyNamingPolicy.CamelCase }
});

var customers = client.GetContainer("novatel", "customers");
var usage     = client.GetContainer("novatel", "usage-events");

var rnd = new Random(42); // fixed seed so every participant gets the same data
string[] plans = ["Prepaid-Basic", "Postpaid-Standard", "Postpaid-Premium"];
decimal[] fees = [9m, 49m, 79m];

Console.WriteLine("Seeding 200 customers...");
var custTasks = new List<Task>();
for (int i = 1; i <= 200; i++)
{
    var id = $"c-{1000 + i}";
    int p = rnd.Next(plans.Length);
    // Customers are mostly Indian subscribers, a few in other NovaTel markets
    var country = rnd.NextDouble() < 0.9 ? "IN" : (rnd.Next(2) == 0 ? "UK" : "DE");
    var profile = new CustomerProfile(id, id, $"Customer {i:000}", country, plans[p], fees[p]);
    custTasks.Add(customers.UpsertItemAsync(profile, new PartitionKey(id)));
}
await Task.WhenAll(custTasks);

Console.WriteLine("Seeding 5,000 usage events (skewed to IN)...");
var evTasks = new List<Task>();
for (int i = 0; i < 5000; i++)
{
    var custNo = 1001 + rnd.Next(200);
    var country = rnd.NextDouble() < 0.9 ? "IN" : (rnd.Next(2) == 0 ? "UK" : "DE");
    var ev = new UsageEvent(
        Id: $"e-{i:00000}",
        CustomerId: $"c-{custNo}",
        Country: country,
        Month: "2026-10",
        MegaBytes: rnd.Next(1, 500),
        TimestampUtc: DateTime.UtcNow.AddMinutes(-rnd.Next(0, 60 * 24 * 20)));
    evTasks.Add(usage.UpsertItemAsync(ev, new PartitionKey(ev.Country)));
}
await Task.WhenAll(evTasks);

Console.WriteLine("Done.");
