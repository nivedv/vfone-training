# NovaTel Day 2, Session 1: Cosmos DB starter pack

STATUS (2026-10-13)
- VERIFIED: all 5 projects (starters) and the 3 trainer-solution files compile with .NET 8 SDK against a stand-in for the
  Cosmos SDK whose signatures were checked against Microsoft Learn (v3.58). This proves the C# is valid and the API calls
  match the documented signatures.
- NOT VERIFIED: anything against the real `Microsoft.Azure.Cosmos` package or a live Cosmos account (NuGet and Azure were not
  reachable from the authoring environment), and the PowerShell scripts were not executed (no PowerShell there).
  Unverified runtime items: Newtonsoft record deserialization, GROUP BY queries, change feed behaviour on serverless,
  seeding throughput, `az` argument syntax.
- DO THIS BEFORE THE SESSION: dry run with one test ID (`p00`): setup, seed, Lab 1 solution, Lab 2 solution. Budget 30 minutes.

## Layout

| Path | Purpose |
| --- | --- |
| `scripts/setup-s1.ps1` | Trainer: creates `rg-novatel-day2-<id>`, serverless Cosmos account, 5 containers, writes `%USERPROFILE%\novatel-day2-<id>.env`. `-Seed` also loads data. |
| `scripts/load-env.ps1` | Participant: `. .\scripts\load-env.ps1 -Id p01` loads endpoint, key and ID into the session. |
| `scripts/cleanup-day2.ps1` | `-Id p01` for one participant, `-All` deletes every `rg-novatel-day2-*` group. |
| `NovaTel.Seed` | Loads 200 customers (`c-1001`..`c-1200`) and 5,000 usage events (about 90% `country = IN`). Idempotent. |
| `NovaTel.Lab1` | Starter for Lab 1. Complete the TODOs in `Operations.cs`. |
| `NovaTel.Lab2/BillingWorker` | Starter for Lab 2 Part A. Complete `HandleChangesAsync`. |
| `NovaTel.Lab2/PlanSimulator` | Complete tool that simulates a plan upgrade. |
| `NovaTel.Lab2/UsageLoader` | Lab 2 Part B: `skew`, `customer-usage` (complete) and `migrate` (participant completes `Migrate.cs`). |
| `trainer-solutions/` | Drop-in replacements for the TODO files. Do not hand out. |

## Run order

```powershell
# Trainer, 60 min before (one per participant ID; run several in parallel windows)
.\scripts\setup-s1.ps1 -Id p01 -Seed

# Participant
. .\scripts\load-env.ps1 -Id p01
dotnet run --project NovaTel.Lab1
dotnet run --project NovaTel.Lab2\BillingWorker       # terminal 1
dotnet run --project NovaTel.Lab2\PlanSimulator -- upgrade c-3001 Postpaid-Premium 79   # terminal 2
dotnet run --project NovaTel.Lab2\UsageLoader -- skew usage-events
```

## Demo IDs

Seeded customers use `c-1001`..`c-1200`. Demo 1 creates and deletes `c-9001`, Demo 2 uses `c-2001`, Lab 2 uses `c-3001`, so nothing collides with seed data.

## Known assumptions to check on the sandbox

- Projects target `net8.0`. If the sandbox only has a newer SDK, change `TargetFramework` (one line per `.csproj`).
- `Microsoft.Azure.Cosmos` is referenced as `3.*` (latest stable 3.x). For a repeatable class, pin the exact version your dry run used.
- NuGet must be reachable from the sandbox. If not, pre-restore once and ship `~\.nuget\packages` or an offline feed.
- Region `centralindia` is the default. Pick the region where Cosmos DB, Container Apps and ACR quota is confirmed.
- Setup takes several minutes per Cosmos account; run all IDs before participants arrive.
