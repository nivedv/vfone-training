# cleanup-day2.ps1 - remove Day 2 resources safely
#
# One participant (own resource group created by setup  -> deletes the whole group):
#   .\cleanup-day2.ps1 -Id p01
# Trainer in a SHARED/EXISTING resource group (deletes only resources tagged day=2 and owner=<Owner>; keeps the group):
#   .\cleanup-day2.ps1 -Id nvtrain -ResourceGroup rg-nvtl-oct26-trainer -Owner novatel-trainer
# Preview without deleting anything:  add -Preview
# Everyone (trainer): .\cleanup-day2.ps1 -All   (only groups named rg-novatel-day2-* that setup created)
param(
    [string]$Id,
    [string]$ResourceGroup,
    [string]$Owner,
    [switch]$All,
    [switch]$Preview
)
$ErrorActionPreference = "Stop"

function Remove-Day2 {
    param([string]$Rg, [string]$OwnerTag)

    if ((& az group exists -n $Rg) -ne "true") { Write-Host "Resource group $Rg not found, nothing to do."; return }

    $createdBy = & az group show -n $Rg --query "tags.createdBy" -o tsv
    if ($createdBy -eq "day2-setup") {
        Write-Host "Resource group $Rg was created by setup -> deleting the whole group."
        if (-not $Preview) { az group delete -n $Rg --yes --no-wait }
        return
    }

    Write-Host "Resource group $Rg is shared/pre-existing -> deleting ONLY resources tagged day=2 and owner=$OwnerTag."
    $ids = & az resource list -g $Rg --query "[?tags.day=='2' && tags.owner=='$OwnerTag'].id" -o tsv
    if (-not $ids) { Write-Host "No matching resources."; return }
    $ids | ForEach-Object { Write-Host "  $_" }
    if (-not $Preview) { az resource delete --ids $ids }
}

if ($All) {
    az group list --query "[?starts_with(name,'rg-novatel-day2-') && tags.createdBy=='day2-setup'].name" -o tsv |
        ForEach-Object { Remove-Day2 -Rg $_ -OwnerTag "" }
}
elseif ($Id) {
    $rg = if ($ResourceGroup) { $ResourceGroup } else { "rg-novatel-day2-$Id" }
    $ownerTag = if ($Owner) { $Owner } else { $Id }
    Remove-Day2 -Rg $rg -OwnerTag $ownerTag
    if (-not $Preview) { Remove-Item (Join-Path $HOME "novatel-day2-$Id.env") -ErrorAction SilentlyContinue }
}
else { throw "Pass -Id <id> (optionally -ResourceGroup and -Owner) or -All" }
