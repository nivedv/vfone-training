# cleanup-day2.ps1 - delete Day 2 resource groups
# One participant:   .\cleanup-day2.ps1 -Id p01
# Everyone (trainer): .\cleanup-day2.ps1 -All
param([string]$Id, [switch]$All)

if ($All) {
    az group list --query "[?starts_with(name,'rg-novatel-day2-')].name" -o tsv |
        ForEach-Object { Write-Host "Deleting $_"; az group delete -n $_ --yes --no-wait }
}
elseif ($Id) {
    az group delete -n "rg-novatel-day2-$Id" --yes --no-wait
    Remove-Item (Join-Path $HOME "novatel-day2-$Id.env") -ErrorAction SilentlyContinue
}
else { throw "Pass -Id <id> or -All" }
