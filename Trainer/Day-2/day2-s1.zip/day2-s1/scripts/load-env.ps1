# load-env.ps1 - load COSMOS_ENDPOINT / COSMOS_KEY / PARTICIPANT_ID into this PowerShell session
# Usage (dot-source so the variables stay in your session):  . .\load-env.ps1 -Id p01
param([Parameter(Mandatory)][string]$Id)

$envFile = Join-Path $HOME "novatel-day2-$Id.env"
if (-not (Test-Path $envFile)) { throw "Missing $envFile. Ask the trainer to re-run setup-s1.ps1 for $Id." }

Get-Content $envFile | ForEach-Object {
    if ($_ -match '^\s*([A-Z_]+)=(.*)$') {
        Set-Item -Path "Env:$($Matches[1])" -Value $Matches[2]
    }
}
Write-Host "Loaded environment for $Id (endpoint: $env:COSMOS_ENDPOINT)"
