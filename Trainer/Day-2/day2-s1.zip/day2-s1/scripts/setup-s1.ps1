# setup-s1.ps1 - Day 2 Session 1 (Cosmos DB) environment
#
# Participant (default, creates its own resource group rg-novatel-day2-<Id>):
#   .\setup-s1.ps1 -Id p01 [-Seed]
# Trainer using an EXISTING resource group:
#   .\setup-s1.ps1 -Id nvtrain -ResourceGroup rg-nvtl-oct26-trainer -Owner novatel-trainer -Seed
#
# Id:            lowercase letters/digits, 2-8 chars. Used in global names (cosmos-novatel-<Id>).
# ResourceGroup: defaults to rg-novatel-day2-<Id>. If it already exists it is REUSED and left untouched.
# Owner:         value of the 'owner' tag on created resources (defaults to Id). Cleanup uses it.
# Location:      defaults to the existing resource group's region, otherwise centralindia.
param(
    [Parameter(Mandatory)][ValidatePattern('^[a-z0-9]{2,8}$')][string]$Id,
    [string]$ResourceGroup = "rg-novatel-day2-$Id",
    [string]$Owner = $Id,
    [string]$Location,
    [switch]$Seed
)
$ErrorActionPreference = "Stop"

# $ErrorActionPreference does not catch failing native commands, so check az's exit code explicitly.
function Invoke-Az {
    $out = & az @args
    if ($LASTEXITCODE -ne 0) { throw "az $($args -join ' ') failed (exit $LASTEXITCODE)" }
    return $out
}

$rg      = $ResourceGroup
$account = "cosmos-novatel-$Id"      # globally unique, 3-44 chars, lowercase/digits/hyphen
$db      = "novatel"

$rgExists = (Invoke-Az group exists -n $rg) -eq "true"
if ($rgExists) {
    if (-not $Location) { $Location = Invoke-Az group show -n $rg --query location -o tsv }
    Write-Host "Reusing existing resource group $rg ($Location). It will not be modified or deleted by setup."
}
else {
    if (-not $Location) { $Location = "centralindia" }
    # createdBy tag lets cleanup know it may delete the whole group
    Invoke-Az group create -n $rg -l $Location --tags createdBy=day2-setup course=azure-dev day=2 owner=$Owner | Out-Null
    Write-Host "Created resource group $rg ($Location)."
}

# Serverless: free tier is limited to one account per subscription and is not available on serverless.
# Tags (day=2, owner=...) are how cleanup finds only the lab resources inside a shared resource group.
Write-Host "Creating Cosmos DB account $account (takes a few minutes)..."
Invoke-Az cosmosdb create -n $account -g $rg `
  --capabilities EnableServerless `
  --default-consistency-level Session `
  --locations regionName=$Location failoverPriority=0 isZoneRedundant=False `
  --tags course=azure-dev day=2 owner=$Owner | Out-Null

Invoke-Az cosmosdb sql database create -a $account -g $rg -n $db | Out-Null

# name -> partition key path
$containers = [ordered]@{
    "customers"             = "/customerId"   # Demo 1 / Lab 1
    "plans"                 = "/customerId"   # Demo 2 / Lab 2 (monitored by change feed)
    "leases"                = "/id"           # change feed processor state
    "billing-notifications" = "/customerId"   # change feed handler output
    "usage-events"          = "/country"      # Lab 2 Part B: seeded skew (few distinct key values)
}
foreach ($c in $containers.GetEnumerator()) {
    Invoke-Az cosmosdb sql container create -a $account -g $rg -d $db -n $c.Key --partition-key-path $c.Value | Out-Null
}

$ep  = Invoke-Az cosmosdb show -n $account -g $rg --query documentEndpoint -o tsv
$key = Invoke-Az cosmosdb keys list -n $account -g $rg --query primaryMasterKey -o tsv

$envFile = Join-Path $HOME "novatel-day2-$Id.env"
"COSMOS_ENDPOINT=$ep`nCOSMOS_KEY=$key`nPARTICIPANT_ID=$Id`nRESOURCE_GROUP=$rg`nOWNER=$Owner" | Out-File $envFile -Encoding ascii
Write-Host "Ready: $account in $rg. Credentials: $envFile"

if ($Seed) {
    . (Join-Path $PSScriptRoot "load-env.ps1") -Id $Id
    dotnet run --project (Join-Path $PSScriptRoot "..\NovaTel.Seed")
    if ($LASTEXITCODE -ne 0) { throw "Seeding failed (exit $LASTEXITCODE)" }
}
