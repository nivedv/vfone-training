// TRAINER SOLUTION - replace NovaTel.Lab1/Operations.cs with this file to demo or to unblock a participant.
using System.Diagnostics;
using Microsoft.Azure.Cosmos;

namespace NovaTel.Lab1;

public class Operations
{
    private readonly Container _customers;
    public Operations(Container customers) => _customers = customers;

    public async Task CreateAsync(string id)
    {
        var sw = Stopwatch.StartNew();
        var item = new CustomerProfile(id, id, "Lab Customer", "IN", "Postpaid-Standard", 49m);
        var r = await _customers.CreateItemAsync(item, new PartitionKey(item.CustomerId));
        Console.WriteLine($"Created {id}: {r.RequestCharge:F2} RU, {sw.ElapsedMilliseconds} ms");
    }

    public async Task ReadAsync(string id)
    {
        var sw = Stopwatch.StartNew();
        var r = await _customers.ReadItemAsync<CustomerProfile>(id, new PartitionKey(id));
        Console.WriteLine($"Read {r.Resource.Name}: {r.RequestCharge:F2} RU, {sw.ElapsedMilliseconds} ms");
    }

    public async Task QueryAsync(string plan, string country)
    {
        var sw = Stopwatch.StartNew();
        var q = new QueryDefinition("SELECT * FROM c WHERE c.plan = @plan AND c.country = @country")
            .WithParameter("@plan", plan).WithParameter("@country", country);
        double ru = 0; int matches = 0;
        using var it = _customers.GetItemQueryIterator<CustomerProfile>(q);
        while (it.HasMoreResults)
        {
            var page = await it.ReadNextAsync();
            ru += page.RequestCharge;
            matches += page.Count;
        }
        Console.WriteLine($"Query matched {matches}: {ru:F2} RU, {sw.ElapsedMilliseconds} ms");
    }

    public async Task ReplaceAsync(string id)
    {
        var sw = Stopwatch.StartNew();
        var read = await _customers.ReadItemAsync<CustomerProfile>(id, new PartitionKey(id));
        var upgraded = read.Resource with { Plan = "Postpaid-Premium", MonthlyFee = 79m };
        var r = await _customers.ReplaceItemAsync(upgraded, id, new PartitionKey(id),
            new ItemRequestOptions { IfMatchEtag = read.ETag });
        Console.WriteLine($"Replaced: {r.RequestCharge:F2} RU, {sw.ElapsedMilliseconds} ms");
    }

    public async Task StaleEtagAsync(string id)
    {
        var first = await _customers.ReadItemAsync<CustomerProfile>(id, new PartitionKey(id));
        var staleEtag = first.ETag;

        // Another "agent" changes the item, so staleEtag no longer matches.
        var changed = first.Resource with { MonthlyFee = first.Resource.MonthlyFee + 1m };
        await _customers.ReplaceItemAsync(changed, id, new PartitionKey(id));

        // Throws CosmosException 412 PreconditionFailed, printed by the Step() wrapper.
        await _customers.ReplaceItemAsync(changed with { MonthlyFee = 99m }, id, new PartitionKey(id),
            new ItemRequestOptions { IfMatchEtag = staleEtag });
    }

    public async Task DeleteAsync(string id)
    {
        var sw = Stopwatch.StartNew();
        var r = await _customers.DeleteItemAsync<CustomerProfile>(id, new PartitionKey(id));
        Console.WriteLine($"Deleted: {r.RequestCharge:F2} RU, {sw.ElapsedMilliseconds} ms");
    }

    public async Task PrintAccountConsistencyAsync(CosmosClient client)
    {
        AccountProperties props = await client.ReadAccountAsync();
        Console.WriteLine($"Account default consistency: {props.Consistency.DefaultConsistencyLevel}");
    }

    public async Task ReadWithConsistencyAsync(string id, ConsistencyLevel level)
    {
        var sw = Stopwatch.StartNew();
        var r = await _customers.ReadItemAsync<CustomerProfile>(id, new PartitionKey(id),
            new ItemRequestOptions { ConsistencyLevel = level });
        Console.WriteLine($"Read with {level}: {r.RequestCharge:F2} RU, {sw.ElapsedMilliseconds} ms");
    }
}
