// TRAINER SOLUTION - replace NovaTel.Lab2/BillingWorker/Program.cs with this file.
using Microsoft.Azure.Cosmos;
using BillingWorker;

using var client = new CosmosClient(Config.Get("COSMOS_ENDPOINT"), Config.Get("COSMOS_KEY"), new CosmosClientOptions
{
    ApplicationName = "NovaTel-BillingWorker",
    SerializerOptions = new CosmosSerializationOptions { PropertyNamingPolicy = CosmosPropertyNamingPolicy.CamelCase }
});

Container plans  = client.GetContainer("novatel", "plans");
Container leases = client.GetContainer("novatel", "leases");
Container notify = client.GetContainer("novatel", "billing-notifications");

ChangeFeedProcessor processor = plans
    .GetChangeFeedProcessorBuilder<PlanChange>("billingProcessor", HandleChangesAsync)
    .WithInstanceName(Environment.MachineName)
    .WithLeaseContainer(leases)
    .WithStartTime(DateTime.UtcNow)
    .Build();

await processor.StartAsync();
Console.WriteLine("Billing processor running. Press Enter to stop.");
Console.ReadLine();
await processor.StopAsync();

async Task HandleChangesAsync(
    ChangeFeedProcessorContext context,
    IReadOnlyCollection<PlanChange> changes,
    CancellationToken cancellationToken)
{
    foreach (var change in changes)
    {
        Console.WriteLine($"[lease {context.LeaseToken}] {change.CustomerId} -> {change.Plan} @ {change.MonthlyFee}");

        var notification = new BillingNotification(
            Id: $"{change.CustomerId}-{change.Plan}-{change.MonthlyFee}",   // deterministic = idempotent
            CustomerId: change.CustomerId,
            Message: $"Plan changed to {change.Plan}; prorate from {DateTime.UtcNow:yyyy-MM-dd}",
            CreatedUtc: DateTime.UtcNow);

        await notify.UpsertItemAsync(notification, new PartitionKey(notification.CustomerId), cancellationToken: cancellationToken);
    }
}
