// TRAINER SOLUTION - replace NovaTel.Lab2/UsageLoader/Migrate.cs with this file.
using System.Diagnostics;
using Microsoft.Azure.Cosmos;

namespace UsageLoader;

public static class Migrate
{
    public static async Task RunAsync(string endpoint, string key, string source, string target)
    {
        using var bulk = new CosmosClient(endpoint, key, new CosmosClientOptions
        {
            ApplicationName = "NovaTel-Migrate",
            AllowBulkExecution = true,
            MaxRetryAttemptsOnRateLimitedRequests = 20,
            MaxRetryWaitTimeOnRateLimitedRequests = TimeSpan.FromSeconds(120),
            SerializerOptions = new CosmosSerializationOptions { PropertyNamingPolicy = CosmosPropertyNamingPolicy.CamelCase }
        });

        var src = bulk.GetContainer("novatel", source);
        var dst = bulk.GetContainer("novatel", target);

        var dstKeyPath = (await dst.ReadContainerAsync()).Resource.PartitionKeyPath;
        if (dstKeyPath != "/customerId")
            throw new InvalidOperationException($"Target must be partitioned on /customerId, but is {dstKeyPath}.");

        var sw = Stopwatch.StartNew();
        long count = 0; double ru = 0;

        using var it = src.GetItemQueryIterator<UsageEvent>("SELECT * FROM c");
        while (it.HasMoreResults)
        {
            var page = await it.ReadNextAsync();
            var writes = page.Select(e => dst.UpsertItemAsync(e, new PartitionKey(e.CustomerId))).ToList();
            var results = await Task.WhenAll(writes);
            ru += results.Sum(r => r.RequestCharge);
            count += results.Length;
        }

        Console.WriteLine($"Migrated {count} items in {sw.Elapsed.TotalSeconds:F1}s, {ru:F0} RU");
    }
}
